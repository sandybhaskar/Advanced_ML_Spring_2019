//============================================================================
// Name        : SJSU.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<cmath> // sqrt, pow, ceil, floor, fabs
#include<cstdlib> // abs, labs, random numbers
#include<ctime>
#include<assert.h> //used to debug a code
#include<fstream>
#include<iomanip>
#include<string>
#include<cctype>

using namespace std;

#define arrays

//#define formatoutput

void swap(int& a,int& b) //In call by reference, you create a reference to the current variable
{
	int temp=a;
	a=b;
	b=temp;
}

void print_infunc(ifstream& in)
{
	int num;
	in>>num;
	cout<<"Printing from within-->"<<num<<endl;
}

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

#ifdef arrays





#endif

#ifdef arith

	//Using power
	int a=5, b=2;
	cout<<"5 to power 2-->"<<pow(double(a),double(b))<<endl;

	//Generating random numbers
	cout<<"Time(0)-"<<time(0)<<endl;
	srand(time(0));
	int randv = rand()%100+90; //Generates a random number between 90 and 100
	cout<<"Random variable-"<<randv<<endl;

#endif

#ifdef func

	//Testing call by reference in functions
		int a1=2, b1=4;
		swap(a1,b1);
		cout<<a1<<"-"<<b1<<endl;

#endif

#ifdef DEBUG
	int a2=5;
	assert(a2==5); //This throw an assertion error saying a2 != 5
	cout<<"After assert --"<<endl;
#endif

#ifdef filehandling
	ifstream instream;
	ofstream outstream;
	instream.open("/home/sancv/Documents/codeblocks/input.txt");
	int val1,val2,val3;
	instream>>val1>>val2>>val3;
	cout<<val1<<val2<<val3<<endl;
	instream.close();
	outstream.open("/home/sancv/Documents/codeblocks/output.txt");
	outstream<<"Values are -"<<val1<<'-'<<val2<<'-'<<val3;
	outstream.close();

	//Functions with stream objects
	string PATH = "/home/sancv/Documents/codeblocks/input.txt";
	instream.open(PATH.c_str()); //I cannot pass string object directly
	print_infunc(instream); //You can pass a stream object ONLY by reference
	instream.close();


#endif

#ifdef filehandling2
	string PATH = "/home/sancv/Documents/codeblocks/input.txt";
	ifstream instream;
	instream.open(PATH.c_str());
	int num;
	char arr[10];
	while(!instream.eof())
	{
		instream.getline(arr,100);
		cout<<arr<<endl;
	}
	instream.close();

	// Two ways of handling strings
	string s;
	cout<<"Enter string"<<endl;
	cin>>s;
	cout<<s;
	char s1[15];
	cout<<"Enter a string"<<endl;
	cin>>s1;
	cout<<s1;

#endif

#ifdef formatoutput
	double a3=67.87689;
	cout<<setw(10)<<a3<<endl; //To set some space before printing!!!
	cout<<setprecision(4)<<a3<<endl; //Number of output digits

	//CHARACTRE I/O -- Reading space
	char ch1,ch2,ch3;
	cin.get(ch1);
	cin.get(ch2);
	cin.get(ch3);
	cout<<"Returning"<<endl;
	cout.put(ch1);
	cout.put(ch2);// Can only be used for characters - put(65) prints A
	cout.put(ch3); //Space is included this way
	cout<<isspace(ch1); //Returns 0 if false, any number if true

#endif


	return 0;
}
