//============================================================================
// Name        : test.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string> //Required if your program uses strings
#include<stdlib.h> // Helps us use exit() which terminates a cpp program
using namespace std; // Make the names cin and cout present in std available to the program

int stack[100], ind; //ind acts as top pointer
#define QSize 20

void push(int x)
{
	++ind;
	stack[ind] = x; //since it is global, you do not have to return
}

void pop()
{
	stack[ind]=0;
	--ind;
}

int top()
{

	return stack[ind];

}

bool isEmpty()
{
	if(ind>=1) return 0;
	return 1;
}

bool check_syntax(string str)
{
	string::iterator it;
	int sz = str.size();
	int symbol[sz];
	int co =0;

	for(it = str.begin(); it!=str.end();it++)
	{
		cout<<"Character is -->"<<*it<<endl;
		switch(*it)
		{
		case '(' :
		case ')' : symbol[co] = 1; ++co; break;
		case '[' :
		case ']' : symbol[co] = 2; ++co; break;
		case '{' :
		case '}' : symbol[co] = 3; ++co; break;

		}
	}

	cout<<"Cryptic string is-->"<<symbol[1]<<endl;
	for(int i=0;i<sz;i++)
	{
		if(isEmpty()) push(symbol[i]);

		else{
			if(symbol[i]==top()) pop();
			else push(symbol[i]);
		}


	}

	if(isEmpty()) return true;
	return false;

}

class Queue
		{
			int *arr; //array to store queue elements
			int capacity; //maximum capacity of the queue
			int front;
			int rear;
			int count; //current size of the queue

			public:
				Queue(int size = QSize); //constructor

				void deq();//popping a value out of the Q
				void enq(int); //pushing a value
				bool QisEmpty(); //Checks if the Queue is empty
				int Front(); //Returns the frontal value in the Queue

		};

		Queue::Queue(int size)
		{
			arr = new int[size];
			capacity = size;
			front = 0;
			rear = -1;
			count = 0;
		}
		void Queue::deq()
		{
			//check for underflow
			if(Queue::QisEmpty()){
				cout<<"Underflow!!!! Program Terminated";
				exit(EXIT_FAILURE);

			}

			//Dequeue the Q
			cout<<"Removing"<< arr[front]<<endl;
			++front;
			--count;

		}

		void Queue::enq(int x)
		{
			//Push a value to the Queue
			if(count == capacity){
				cout<<"Overflow!! Program Terminated";
				exit(EXIT_FAILURE);
			}

			++rear;
			cout<<"Adding -"<<x;
			arr[rear] = x;
			++count;
		}

		bool Queue::QisEmpty()
		{
			if(rear<front) return true;
			else return false;
		}

		int Queue::Front()
		{
			if(QisEmpty())
			{
				cout<<"Queue Empty"<<endl;
				exit(EXIT_FAILURE);
			}
			return arr[front];
		}

int binary_search(int a[], int num, int left, int right)
{
	cout<<"Inside binary search function";
	if(left>right)
		return -1;

	int mid = (left+right)/2;
	cout<<"The value of mid is-"<<a[mid];
	if(num == a[mid]) return mid;
	else if(num>a[mid])
	{
		left = mid+1;
		return binary_search(a,num,left,right);
	}
	else
	{
		right = mid-1;
		return binary_search(a,num,left,right);

	}

}

int count_occ(int *a, int val, int left, int right, bool flag)
{
	cout<<"Counting...";
	int mid = (left+right)/2;
	int result =-1;
	while(left<right)
	{
		if(a[mid]==val)
		{
			result = mid;
			if(flag){
				right = mid-1;
			}
			else left = mid+1;
		}
		else if(a[mid]>val) left = mid+1;
		else right = mid-1;

	}
return result;
}


int main() {

	/*
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	cout<< "Implementing a stack with an array";
	push(1);
	push(2);
	cout<<"Top == "<<top()<<endl;
	pop();
	cout<<"Top after pop operation ==" << top()<<endl;
	*/

	// ---- Handling real numbers with cout -------------------
	cout.setf(ios::showpoint); //Always show decimal points
	cout.precision(3);
	float f=4;// precision(3) --> 2 digits after the decimal point
	cout<<f<<endl;
	cout.setf(ios::fixed); // Always displays in fixed point notations


	//------ Syntax test for parantheses --------------------------
	cout<<"To check if the parantheses have been rightly placed!"<<endl;
	string str;
	cout<< "Enter the string to be validated"<<endl;
	getline(cin,str);
	cout<<"You have entered the string --> "<<str<<endl;
	cout<<"Syntax test on....";
	bool res;
	res=check_syntax(str);
	cout<<"Test results =="<<res<<endl;

	//---- Implementing a Queue ----------------------
	Queue q;
	q.enq(1);
	q.enq(2);
	q.enq(3);
	cout<<"The front value is -->"<<q.Front();
	q.deq();
	cout<<"Front value after deque operation is -->"<<q.Front();


	//------ Implementing Binary search algorithm-------------------
	int a[8] = {1,1,1,3,6,20,30,48};
	int index,val1;
	cout<<"Enter the number"<<endl;
	cin>>val1;
	cout<<"CHECKPOINT";
	index = binary_search(a,val1,0,8);
	if(index>-1) cout<< "The element is present in the index position of-->"<<index;
	else cout<<"Element is not present in the array";


	//number of occurrences of a value
	int n_last, n_first, n;
	n_first = count_occ(a,1,0,8,1);
	n_last = count_occ(a,1,0,8,0);
	if(n_first==-1) cout<<"Value does not exist";
	else{
		n = n_last-n_first +1;
		cout<<"The number of occurrences of 1 ="<<n;}

	return 0;
}
