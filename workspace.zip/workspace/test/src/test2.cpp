//============================================================================
// Name        : test.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Test for parantheses
//============================================================================

#include <iostream>
using namespace std;

int check()
{
	cout<<"Program to determine if the paranthesesare syntactically correct";
	return 0;
}
