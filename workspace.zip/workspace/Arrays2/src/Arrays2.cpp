//============================================================================
// Name        : Arrays2.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;


void merge(int arr[], int l, int m, int h)
{
	int i,j,k;
	int n1 = m-l+1;
	cout<<"n1"<<n1<<endl;

	int n2= h-m;
	cout<<"n2"<<n2<<endl;

	int L[n1], R[n2];

	cout<<"Left array"<<endl;
	for(i=0;i<n1;i++)
	{
		L[i] = arr[l+i];
		cout<<L[i]<<'-';
	}
	cout<<endl;

	cout<<"Right array"<<endl;
	for(j=0;j<n2;j++)
	{
		R[j]=arr[m+1+j];
		cout<<R[j]<<'-';
	}
	cout<<endl;

	i=j=k=0;

	while(i<n1 && j<n2)
	{

		if(L[i]<R[j])
		{
			arr[k] = L[i]; i++;

		}

		else
		{
			arr[k] = R[j]; j++;

		}

		k++;
	}

	while(i<n1)
	{
		arr[k]=L[i];
		i++;
		k++;
	}

	while(j<n2)
	{
		arr[k]=R[j];
		j++; k++;
	}
}

void merge_sort(int arr[],int low, int high)
{

	if(low<high){
		int mid=(low+high)/2;
		merge_sort(arr,low,mid);
		merge_sort(arr,mid+1,high);


		merge(arr,low,mid,high);


	}

}


void print_array(int arr[],int n)
{
	for(int p=0;p<n;p++)
	{
		cout<<arr[p]<<'-';
	}
}


int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	//Merge sort
	int arr[] = {1,8,5,3,2,10};
	int n = sizeof(arr)/sizeof(*arr);
	merge_sort(arr,0,n-1);cout<<endl;
	print_array(arr,n);


	return 0;
}
