//============================================================================
// Name        : udemy2.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <algorithm> //For sorting
using namespace std;
#define run

int cmp(int X,int Y)
{
	return X>Y;
}

void test(int arr[])
{
	for(int i=0;i<9;i++)
	{
		cout<<arr[i]<<endl;
	}
	cout<<sizeof(arr)<<endl;
	cout<<sizeof(*arr)<<endl;
	cout<<"Size of the array - "<<sizeof(arr)/sizeof(*arr);
}

int check(int arr[], int sz, int left, int right, int flag,int val)
{
	cout<<"Received params"<<endl;
	int mid=(left+right)/2;
	int result = -1;
	cout<<"Result"<<result<<endl;
	while(left<=right)
	{
		if(arr[mid]==val)
		{
			result=mid;
			if(flag) right=mid-1;
			else left = mid+1;

		}

		else if(arr[mid]<val) {cout<<"HERE 1"<<endl; left=mid+1;}
		else {cout<<"HERE 2"<<endl;right=mid-1;};
		mid = (left+right)/2;
	}

	return result;
}

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	/*------------ Fast Sorting using STL ------------------------
	int A[5] = {10,6,5,2,8};
	sort(A,A+5); //sorts in ascending order
	for(int i=0;i<5;i++) cout<<A[i]<<'-';
	cout<<endl;
	sort(A,A+5,cmp); //sorts in descending order
	for(int i=0;i<5;i++) cout<<A[i]<<'-';
	cout<<endl;
	*/

	/* Counting number of occurrences of a number in an array
	 *  Majority element problem is an extension of the same
	 */
#ifdef run
	int arr[] = {1,1,2,2,2,2,2,3,4,5,6,7,8,9};
	cout<<"Size of the array - "<<sizeof(arr)/sizeof(*arr)<<endl;
	int sz = sizeof(arr)/sizeof(*arr);
	int val=2;
	int n_first = check(arr,sz,0,sz-1,1,val); //first occurrence
	cout<<"First occurrence"<<n_first<<endl;
	int n_last = check(arr,sz,0,sz-1,0,val); // last occurrence
	cout<<"Last occurrence "<<n_last<<endl;
	int n = n_last - n_first +1;
	cout<<"Total number of occurrences -"<<n<<endl;
	return 0;
#endif




}
