//============================================================================
// Name        : Arrays.cpp
// Author      : Sandhya Bhaskar
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int find_pivot(int arr[], int low, int high)
{
	int mid=(low+high)/2;

	if(arr[mid]>arr[mid+1]) return mid;
	else if(arr[mid]<arr[mid-1]) return mid-1;
	else if(arr[low]>=arr[mid]) return find_pivot(arr,low,mid-1);
	else return find_pivot(arr,mid+1,high);
 }

int binary_search(int a[],int low,int high,int val)
{
	int mid=(low+high)/2;
	while(low<=high)
	{
		if(a[mid]==val) return mid;
		if(a[mid]>val) high=mid-1;
		else low=mid+1;
		mid =(low+high)/2;

	}

	return -1;

}

int search(int a[], int low, int high,int val)
{
	// Find the pivot point
	int pivot = find_pivot(a,low,high);
	cout<<"Pivot point-->"<<pivot<<endl;

	// Perform BS on the corresponding subarray
	if(val==a[pivot]) return pivot;
	else if(a[low]<=val) return binary_search(a,low,pivot-1,val);
	else return binary_search(a,pivot+1,high,val);


}


void swap(int& a, int& b)
{
	int temp =a;
	a=b;
	b=temp;
}

void bubble_sort(int a[],int n)
{
	for(int i=0;i<n-1;i++)
		for(int j=0;j<n-i-1;j++)
		{

			if(a[j]>a[j+1]) swap(a[j],a[j+1]);
		}
}

void insertion_sort(int a[],int n)
{
	int i,j,key;
	for(i=0;i<n;i++)
	{
		key=a[i];
		j=i-1;

		while(j>=0 && a[j]>key)
		{
			a[j+1]=a[j];
			j=j-1;
		}

		a[j+1]=key;



	}
}

void print_array(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<'-';
	}
	cout<<endl;
}



int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	// Printing characters
	char arr[3] = {'a','b','c'};
	for(int i=0;i<3;i++) cout<<arr[i];
	cout<<endl;

	// Search an element in a sorted and rotated array
	int a[]={3,4,5,6,7,1,2};
	int sz=sizeof(a)/sizeof(*a);
	int val=1;
	int index=search(a,0,sz-1,val);
	cout<<"The value was found at index-->"<<index<<endl;

	// Bubble sort
	int a1[] ={1,5,2,3,10,8,9,0};
	int sz1 = sizeof(a1)/sizeof(*a1);
	bubble_sort(a1,sz1); //Whatever change you make in the array in bubblesort reflects onto the original array
	cout<<"Bubble sort"<<endl;
	print_array(a1,sz1);

	//Insertion sort
	cout<<"Insertion sort"<<endl;
	int a2[] ={1,5,2,3,10,8,9,0};
	insertion_sort(a2,sz1);
	print_array(a2,sz1);


	return 0;
}
